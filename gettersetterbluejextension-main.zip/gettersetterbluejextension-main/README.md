# gettersetterbluejextension
GetterSetter es a BlueJ 5.0 Extension. It generate code to get/set methods and generate GUI JavaFX to edit object on BlueJ using get/set methods

View video at doc/video

View screenshoot at doc/GetterSetter-ScreenShot.pdf

View javadoc at doc/api-java-doc

View source BlueJProject at src/BlueJProject-GetterSetterExtension

Download JAR Extension at dist/
GetterSetter_BlueJ5-JDK11.jar
GetterSetter_BlueJ5-JDK14.jar


